#include "mex.h" /* Always include this */
void mexFunction(int nlhs, mxArray *plhs[], /* Output variables */
int nrhs, const mxArray *prhs[]) /* Input variables */
{
mexPrintf("welcome !to group'18 App "); /* Do something interesting */
return;
}