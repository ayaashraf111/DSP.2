cd('E:\3rd year\2_nd term\DSP\TASKS\TASK2\CMEX')
mex Tak2.c
Tak2
